/**
 * ==========================================================================
 * DSSC STUDENT SERVICES DASHBOARD - JAVASCRIPT
 * Davao del Sur State College (Educational Laboratory Prototype)
 * Features:
 *  1. DSSC Portal Login Screen Gateway (Student & Admin Entrance)
 *  2. Mobile Navigation Drawer Controls
 *  3. Real-Time Table Search / Filtering
 *  4. Character Counter & File Upload Label Handler
 *  5. Form Validation & Dynamic Request Submission
 *  6. View Request Details Modal Dialog
 *  7. Role Switcher & Profile Adaptation
 * ==========================================================================
 */

document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  // ------------------------------------------------------------------------
  // 1. DSSC Portal Login Screen Gateway & Logout Handler
  // ------------------------------------------------------------------------
  const loginScreen = document.getElementById("loginScreen");
  const appLayout = document.getElementById("appLayout");
  const loginForm = document.getElementById("loginForm");
  const tabStudent = document.getElementById("tabStudent");
  const tabAdmin = document.getElementById("tabAdmin");
  const loginIdLabel = document.getElementById("loginIdLabel");
  const loginIdInput = document.getElementById("loginId");
  const loginSubmitBtn = document.getElementById("loginSubmitBtn");
  const quickStudentBtn = document.getElementById("quickStudentBtn");
  const quickAdminBtn = document.getElementById("quickAdminBtn");
  const logoutBtn = document.getElementById("logoutBtn");

  let selectedRole = "student";

  function setLoginRole(role) {
    selectedRole = role;
    if (role === "admin") {
      if (tabStudent) tabStudent.classList.remove("active");
      if (tabAdmin) tabAdmin.classList.add("active");
      if (loginIdLabel) loginIdLabel.textContent = "Employee / Staff ID";
      if (loginIdInput) loginIdInput.value = "ADMIN-2026-001";
      if (loginSubmitBtn) loginSubmitBtn.innerHTML = `<span>Sign In as Administrator</span> &rarr;`;
    } else {
      if (tabAdmin) tabAdmin.classList.remove("active");
      if (tabStudent) tabStudent.classList.add("active");
      if (loginIdLabel) loginIdLabel.textContent = "Student ID";
      if (loginIdInput) loginIdInput.value = "2024-00124";
      if (loginSubmitBtn) loginSubmitBtn.innerHTML = `<span>Sign In as Student</span> &rarr;`;
    }
  }

  if (tabStudent) {
    tabStudent.addEventListener("click", () => setLoginRole("student"));
  }

  if (tabAdmin) {
    tabAdmin.addEventListener("click", () => setLoginRole("admin"));
  }

  function enterDashboard(role) {
    applyRole(role);
    if (loginScreen) {
      loginScreen.hidden = true;
      loginScreen.style.display = "none";
    }
    if (appLayout) {
      appLayout.style.display = "flex";
    }
  }

  function exitToLogin() {
    if (appLayout) {
      appLayout.style.display = "none";
    }
    if (loginScreen) {
      loginScreen.hidden = false;
      loginScreen.style.display = "flex";
    }
  }

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      enterDashboard(selectedRole);
    });
  }

  if (quickStudentBtn) {
    quickStudentBtn.addEventListener("click", () => {
      setLoginRole("student");
      enterDashboard("student");
    });
  }

  if (quickAdminBtn) {
    quickAdminBtn.addEventListener("click", () => {
      setLoginRole("admin");
      enterDashboard("admin");
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", exitToLogin);
  }

  // ------------------------------------------------------------------------
  // 2. Mobile Sidebar Navigation Drawer Controls
  // ------------------------------------------------------------------------
  const sidebar = document.getElementById("sidebar");
  const sidebarToggleBtn = document.getElementById("sidebarToggleBtn");
  const sidebarCloseBtn = document.getElementById("sidebarCloseBtn");
  const sidebarOverlay = document.getElementById("sidebarOverlay");
  const navLinks = document.querySelectorAll(".nav-link");

  function openSidebar() {
    if (sidebar) sidebar.classList.add("is-open");
    if (sidebarOverlay) sidebarOverlay.classList.add("is-active");
    if (sidebarToggleBtn) sidebarToggleBtn.setAttribute("aria-expanded", "true");
  }

  function closeSidebar() {
    if (sidebar) sidebar.classList.remove("is-open");
    if (sidebarOverlay) sidebarOverlay.classList.remove("is-active");
    if (sidebarToggleBtn) sidebarToggleBtn.setAttribute("aria-expanded", "false");
  }

  if (sidebarToggleBtn) {
    sidebarToggleBtn.addEventListener("click", () => {
      const isOpen = sidebar && sidebar.classList.contains("is-open");
      if (isOpen) {
        closeSidebar();
      } else {
        openSidebar();
      }
    });
  }

  if (sidebarCloseBtn) {
    sidebarCloseBtn.addEventListener("click", closeSidebar);
  }

  if (sidebarOverlay) {
    sidebarOverlay.addEventListener("click", closeSidebar);
  }

  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.forEach((item) => {
        item.classList.remove("active");
        item.removeAttribute("aria-current");
      });
      link.classList.add("active");
      link.setAttribute("aria-current", "page");

      if (window.innerWidth < 1100) {
        closeSidebar();
      }
    });
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && sidebar && sidebar.classList.contains("is-open")) {
      closeSidebar();
      if (sidebarToggleBtn) sidebarToggleBtn.focus();
    }
  });

  // ------------------------------------------------------------------------
  // 3. Real-Time Table Search Filter
  // ------------------------------------------------------------------------
  const tableSearchInput = document.getElementById("tableSearchInput");
  const requestsTableBody = document.getElementById("requestsTableBody");
  const showingRowsCount = document.getElementById("showingRowsCount");
  const totalRowsCount = document.getElementById("totalRowsCount");

  function updateTableCounts() {
    if (!requestsTableBody) return;
    const allRows = requestsTableBody.querySelectorAll("tr");
    let visibleCount = 0;
    allRows.forEach((row) => {
      if (row.style.display !== "none") visibleCount++;
    });

    if (showingRowsCount) showingRowsCount.textContent = visibleCount;
    if (totalRowsCount) totalRowsCount.textContent = allRows.length;
  }

  if (tableSearchInput && requestsTableBody) {
    tableSearchInput.addEventListener("input", () => {
      const query = tableSearchInput.value.toLowerCase().trim();
      const rows = requestsTableBody.querySelectorAll("tr");

      rows.forEach((row) => {
        const text = row.textContent.toLowerCase();
        if (text.includes(query)) {
          row.style.display = "";
        } else {
          row.style.display = "none";
        }
      });
      updateTableCounts();
    });
  }

  // ------------------------------------------------------------------------
  // 4. Form Input Handlers (Character Counter & File Upload)
  // ------------------------------------------------------------------------
  const requestDetailsTextarea = document.getElementById("requestDetails");
  const charCounter = document.getElementById("charCounter");
  const supportingDocInput = document.getElementById("supportingDoc");
  const chosenFileName = document.getElementById("chosenFileName");

  if (requestDetailsTextarea && charCounter) {
    requestDetailsTextarea.addEventListener("input", () => {
      const len = requestDetailsTextarea.value.length;
      charCounter.textContent = `${len}/500`;
      if (len >= 10) {
        clearError(requestDetailsTextarea, document.getElementById("detailsError"));
      }
    });
  }

  if (supportingDocInput && chosenFileName) {
    supportingDocInput.addEventListener("change", () => {
      if (supportingDocInput.files && supportingDocInput.files.length > 0) {
        chosenFileName.textContent = supportingDocInput.files[0].name;
      } else {
        chosenFileName.textContent = "No file chosen";
      }
    });
  }

  // ------------------------------------------------------------------------
  // 5. Form Validation & Dynamic Submission
  // ------------------------------------------------------------------------
  const serviceForm = document.getElementById("serviceRequestForm");
  const serviceCategorySelect = document.getElementById("serviceCategory");
  const categoryError = document.getElementById("categoryError");
  const detailsError = document.getElementById("detailsError");
  const formSuccessMessage = document.getElementById("formSuccessMessage");
  const successDetailText = document.getElementById("successDetailText");
  const resetBtn = document.getElementById("resetBtn");
  const metricPendingCount = document.getElementById("metricPendingCount");

  let nextRequestSeq = 105;

  function showError(field, errorEl, msg) {
    field.classList.add("is-invalid");
    if (errorEl) {
      errorEl.textContent = msg;
      errorEl.hidden = false;
    }
  }

  function clearError(field, errorEl) {
    field.classList.remove("is-invalid");
    if (errorEl) {
      errorEl.textContent = "";
      errorEl.hidden = true;
    }
  }

  if (serviceCategorySelect) {
    serviceCategorySelect.addEventListener("change", () => {
      if (serviceCategorySelect.value.trim() !== "") {
        clearError(serviceCategorySelect, categoryError);
      }
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      clearError(serviceCategorySelect, categoryError);
      clearError(requestDetailsTextarea, detailsError);
      if (charCounter) charCounter.textContent = "0/500";
      if (chosenFileName) chosenFileName.textContent = "No file chosen";
      if (formSuccessMessage) formSuccessMessage.hidden = true;
    });
  }

  if (serviceForm) {
    serviceForm.addEventListener("submit", (e) => {
      e.preventDefault();
      if (formSuccessMessage) formSuccessMessage.hidden = true;

      let isValid = true;
      const catVal = serviceCategorySelect ? serviceCategorySelect.value.trim() : "";
      const detailsVal = requestDetailsTextarea ? requestDetailsTextarea.value.trim() : "";

      if (catVal === "") {
        showError(serviceCategorySelect, categoryError, "Please select a service category.");
        isValid = false;
      } else {
        clearError(serviceCategorySelect, categoryError);
      }

      if (detailsVal === "") {
        showError(requestDetailsTextarea, detailsError, "Please provide brief details of your request.");
        isValid = false;
      } else if (detailsVal.length < 10) {
        showError(requestDetailsTextarea, detailsError, `Please enter at least 10 characters (current: ${detailsVal.length}).`);
        isValid = false;
      } else {
        clearError(requestDetailsTextarea, detailsError);
      }

      if (!isValid) {
        if (catVal === "") {
          serviceCategorySelect.focus();
        } else {
          requestDetailsTextarea.focus();
        }
        return;
      }

      // Generate new Tracking ID & Formatted Date
      const generatedId = `DSSC-2026-0${nextRequestSeq++}`;
      const dateOpts = { month: "short", day: "2-digit", year: "numeric" };
      const formattedDate = new Intl.DateTimeFormat("en-US", dateOpts).format(new Date());

      // Create new table row matching screenshot styling
      const newRow = document.createElement("tr");
      newRow.setAttribute("data-id", generatedId);
      newRow.setAttribute("data-type", catVal);
      newRow.setAttribute("data-date", formattedDate);
      newRow.setAttribute("data-status", "Pending");
      newRow.setAttribute("data-notes", detailsVal);

      newRow.innerHTML = `
        <td data-label="Request ID">
          <div class="req-id-cell">
            <span class="row-type-icon" aria-hidden="true">📄</span>
            <span class="id-code">${generatedId}</span>
          </div>
        </td>
        <td class="service-name" data-label="Service Type">${escapeHtml(catVal)}</td>
        <td class="date-cell" data-label="Date Filed">${formattedDate}</td>
        <td data-label="Status">
          <span class="status-pill pill-pending">
            <span class="status-dot"></span> Pending
          </span>
        </td>
        <td data-label="Actions">
          <div class="row-action-cell">
            <button type="button" class="btn-row-view" aria-label="View request ${generatedId}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
              <span>View</span>
              <span class="chevron" aria-hidden="true">&rsaquo;</span>
            </button>
            <div class="admin-inline-actions" hidden>
              <button type="button" class="btn-adm-approve" title="Approve this request">Approve</button>
              <button type="button" class="btn-adm-process" title="Mark as processing">Process</button>
            </div>
          </div>
        </td>
      `;

      if (requestsTableBody) {
        requestsTableBody.insertBefore(newRow, requestsTableBody.firstChild);
      }

      // Increment Pending metric counter
      if (metricPendingCount) {
        const count = parseInt(metricPendingCount.textContent, 10) || 0;
        metricPendingCount.textContent = `${count + 1} Pending`;
      }

      // Display success alert
      if (successDetailText) {
        successDetailText.innerHTML = `Your <strong>${escapeHtml(catVal)}</strong> has been recorded with ID <strong>${generatedId}</strong>.`;
      }
      if (formSuccessMessage) {
        formSuccessMessage.hidden = false;
        formSuccessMessage.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }

      // Reset form
      serviceForm.reset();
      if (charCounter) charCounter.textContent = "0/500";
      if (chosenFileName) chosenFileName.textContent = "No file chosen";
      updateTableCounts();
    });
  }

  // ------------------------------------------------------------------------
  // 6. View Request Details Modal Handler (Guaranteed Hidden by Default)
  // ------------------------------------------------------------------------
  const viewModal = document.getElementById("viewRequestModal");
  const modalCloseBtn = document.getElementById("modalCloseBtn");
  const modalDismissBtn = document.getElementById("modalDismissBtn");
  const modalReqId = document.getElementById("modalReqId");
  const modalServiceType = document.getElementById("modalServiceType");
  const modalDateFiled = document.getElementById("modalDateFiled");
  const modalStatusBadge = document.getElementById("modalStatusBadge");
  const modalNotes = document.getElementById("modalNotes");

  let previousActiveElement = null;

  function openModal(row) {
    if (!viewModal || !row) return;
    previousActiveElement = document.activeElement;

    const reqId = row.getAttribute("data-id") || row.querySelector(".id-code")?.textContent.trim();
    const sType = row.getAttribute("data-type") || row.querySelector(".service-name")?.textContent.trim();
    const dDate = row.getAttribute("data-date") || row.querySelector(".date-cell")?.textContent.trim();
    const status = row.getAttribute("data-status") || "Pending";
    const notes = row.getAttribute("data-notes") || "Submitted for student records verification and administrative processing.";

    if (modalReqId) modalReqId.textContent = reqId;
    if (modalServiceType) modalServiceType.textContent = sType;
    if (modalDateFiled) modalDateFiled.textContent = dDate;
    if (modalNotes) modalNotes.textContent = notes;

    let badgeClass = "pill-pending";
    if (status.toLowerCase().includes("approved")) badgeClass = "pill-approved";
    if (status.toLowerCase().includes("processing")) badgeClass = "pill-processing";

    if (modalStatusBadge) {
      modalStatusBadge.innerHTML = `
        <span class="status-pill ${badgeClass}">
          <span class="status-dot"></span> ${escapeHtml(status)}
        </span>
      `;
    }

    viewModal.style.display = "flex";
    viewModal.classList.add("is-open");
    if (modalCloseBtn) modalCloseBtn.focus();
  }

  function closeModal() {
    if (viewModal) {
      viewModal.style.display = "none";
      viewModal.classList.remove("is-open");
      if (previousActiveElement && typeof previousActiveElement.focus === "function") {
        previousActiveElement.focus();
      }
    }
  }

  if (modalCloseBtn) modalCloseBtn.addEventListener("click", closeModal);
  if (modalDismissBtn) modalDismissBtn.addEventListener("click", closeModal);

  if (viewModal) {
    viewModal.addEventListener("click", (e) => {
      if (e.target === viewModal) closeModal();
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && viewModal && viewModal.style.display !== "none") {
      closeModal();
    }
  });

  // Table row click listener for "View" button & Admin inline actions
  if (requestsTableBody) {
    requestsTableBody.addEventListener("click", (e) => {
      const viewBtn = e.target.closest(".btn-row-view");
      if (viewBtn) {
        const row = viewBtn.closest("tr");
        openModal(row);
        return;
      }

      // Admin Approve Action
      const approveBtn = e.target.closest(".btn-adm-approve");
      if (approveBtn) {
        const row = approveBtn.closest("tr");
        const statusCell = row.querySelector(".status-pill");
        if (statusCell) {
          statusCell.className = "status-pill pill-approved";
          statusCell.innerHTML = `<span class="status-dot"></span> Approved`;
          row.setAttribute("data-status", "Approved");
        }
        approveBtn.disabled = true;
        approveBtn.textContent = "Approved";

        if (metricPendingCount) {
          const c = parseInt(metricPendingCount.textContent, 10) || 0;
          if (c > 0) metricPendingCount.textContent = c - 1;
        }
        return;
      }

      // Admin Process Action
      const processBtn = e.target.closest(".btn-adm-process");
      if (processBtn) {
        const row = processBtn.closest("tr");
        const statusCell = row.querySelector(".status-pill");
        if (statusCell) {
          statusCell.className = "status-pill pill-processing";
          statusCell.innerHTML = `<span class="status-dot"></span> Processing`;
          row.setAttribute("data-status", "Processing");
        }
        processBtn.disabled = true;
        processBtn.textContent = "In Process";
        return;
      }
    });
  }

  // ------------------------------------------------------------------------
  // 7. Role Switcher & Profile Adaptation
  // ------------------------------------------------------------------------
  const profileAvatar = document.getElementById("profileAvatar");
  const profileName = document.getElementById("profileName");
  const profileMeta = document.getElementById("profileMeta");
  const serviceFormCard = document.getElementById("service-form-card");
  const adminNoticeBanner = document.getElementById("adminNoticeBanner");
  const navItemRequestService = document.getElementById("navItemRequestService");
  const navLabelRequests = document.getElementById("navLabelRequests");

  const cardTitle1 = document.getElementById("cardTitle1");
  const cardMetric1 = document.getElementById("cardMetric1");
  const cardDesc1 = document.getElementById("cardDesc1");

  const cardTitle2 = document.getElementById("cardTitle2");
  const cardDesc2 = document.getElementById("cardDesc2");

  const cardTitle3 = document.getElementById("cardTitle3");
  const cardMetric3 = document.getElementById("cardMetric3");
  const cardDesc3 = document.getElementById("cardDesc3");

  function applyRole(role) {
    if (role === "admin") {
      document.body.classList.add("admin-mode");

      // 1. Profile details for Admin
      if (profileAvatar) profileAvatar.textContent = "RG";
      if (profileName) profileName.textContent = "Office of Registrar";
      if (profileMeta) profileMeta.textContent = "DSSC Staff - Registrar";

      // 2. Hide student form from Admin view
      if (serviceFormCard) serviceFormCard.hidden = true;
      if (navItemRequestService) navItemRequestService.hidden = true;
      if (navLabelRequests) navLabelRequests.textContent = "Manage Requests";

      // 3. Switch summary metrics for Admin
      if (cardTitle1) cardTitle1.textContent = "Total Enrolled";
      if (cardMetric1) cardMetric1.textContent = "1,420";
      if (cardDesc1) cardDesc1.textContent = "Officially enrolled college students";

      if (cardTitle2) cardTitle2.textContent = "Pending Requests";
      if (metricPendingCount) metricPendingCount.textContent = "3";
      if (cardDesc2) cardDesc2.textContent = "Awaiting approval or review";

      if (cardTitle3) cardTitle3.textContent = "Processed Today";
      if (cardMetric3) cardMetric3.textContent = "18";
      if (cardDesc3) cardDesc3.textContent = "Requests approved today";
    } else {
      document.body.classList.remove("admin-mode");

      // 1. Revert to Student Profile (Juan Dela Cruz Santos)
      if (profileAvatar) profileAvatar.textContent = "JS";
      if (profileName) profileName.textContent = "Juan Dela Cruz Santos";
      if (profileMeta) profileMeta.textContent = "BSIT - 3rd Year";

      // 2. Restore student form
      if (serviceFormCard) serviceFormCard.hidden = false;
      if (navItemRequestService) navItemRequestService.hidden = false;
      if (navLabelRequests) navLabelRequests.textContent = "My Requests";

      // 3. Student Summary Cards: Shows their Account, Request & Clearance Status!
      if (cardTitle1) cardTitle1.textContent = "Active Units";
      if (cardMetric1) cardMetric1.textContent = "21 Units";
      if (cardDesc1) cardDesc1.textContent = "Enrollment: Approved (1st Sem)";

      if (cardTitle2) cardTitle2.textContent = "Pending Requests";
      if (metricPendingCount) metricPendingCount.textContent = "3 Pending";
      if (cardDesc2) cardDesc2.textContent = "3 Requests awaiting review";

      if (cardTitle3) cardTitle3.textContent = "Clearance Deficiencies";
      if (cardMetric3) cardMetric3.textContent = "2 Deficiencies";
      if (cardDesc3) cardDesc3.textContent = "Library & Dept requirements pending";
    }
  }

  // Helper function to safely escape HTML
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // Initial setup: ensure student role metrics and modal closed
  applyRole("student");
  closeModal();
  updateTableCounts();
});
